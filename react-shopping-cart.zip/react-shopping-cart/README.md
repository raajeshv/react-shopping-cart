

## Shopping Cart assignment for Adobe-J2W by Rajesh Kannan 

This is a simple e-commerce application, built using **React** and **Redux**.

# should contain 
filters,search box and products

# Dependencies

install node and npm
to check that node -v and npm -v


# Installation

npm install / npm i


# To Run

npm run build


## Dev Server

npm start

## to test

npm test

