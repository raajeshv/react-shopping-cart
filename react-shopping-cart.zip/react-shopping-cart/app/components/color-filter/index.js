export { ColorFilter } from './src/color-filter';
