export { Details } from './src/details';
