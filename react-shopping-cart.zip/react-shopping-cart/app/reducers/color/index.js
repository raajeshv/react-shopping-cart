export { ColorRedReducer, ColorBlueReducer, ColorGreenReducer, ColorYellowReducer, ColorBrownReducer } from './src/color';
