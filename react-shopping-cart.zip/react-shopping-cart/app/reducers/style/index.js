export { StyleReducer } from './src/style';
