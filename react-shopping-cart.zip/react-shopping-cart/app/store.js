export const Store = {
    cart: {
        total: '0',
        products: [
            {
                id: ''
            },
            {
                id: ''
            },
            {
                id: ''
            },
            {
                id: ''
            }
        ]
    },
    wishlist: []
};